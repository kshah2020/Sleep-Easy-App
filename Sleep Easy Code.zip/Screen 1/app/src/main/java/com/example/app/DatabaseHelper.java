package com.example.app;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "sleepFinal.db";
    public static final String TABLE_WAKE = "awake";
    public static final String TABLE_SLEEP = "asleep";
    public static final String TABLE_RATING = "rating";

    public static final String COL_AWAKE_1 = "ID";
    public static final String COL_WAKE_2 = "wake";

    public static final String COL_ASLEEP_1 = "ID";
    public static final String COL_SLEEP_2 = "sleep";

    public static final String COL_RATING_1 = "ID";
    public static final String COL_RATING_2 = "rating";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_WAKE + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, wake TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_SLEEP + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, sleep TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_RATING + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, rating TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WAKE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SLEEP);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RATING);
        onCreate(db);
    }

    public List<String> getAwakeData(){
        List<String> returnL = new ArrayList<>();

        String qry = "SELECT * FROM " + TABLE_WAKE;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(qry,null);

        if(cursor.moveToFirst()){
            do{
                String rating = cursor.getString(1);
                returnL.add(rating);
            }while(cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return returnL;
    }

    public List<String> getSleepData(){
        List<String> returnL = new ArrayList<>();

        String qry = "SELECT * FROM " + TABLE_SLEEP;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(qry,null);

        if(cursor.moveToFirst()){
            do{
                String rating = cursor.getString(1);
                returnL.add(rating);
            }while(cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return returnL;
    }

    public List<String> getRatings(){
        List<String> returnL = new ArrayList<>();

        String qry = "SELECT * FROM " + TABLE_RATING;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(qry,null);

        if(cursor.moveToFirst()){
            do{
                String rating = cursor.getString(1);
                returnL.add(rating);
            }while(cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return returnL;
    }

}
