package com.example.app;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Menu extends AppCompatActivity {
    TextView title;
    ListView lvProgram;
    String[] name = {"Home Page", "Diary and Journaling Screen","Track Your Sleep", "View Resources", "About You Survey"};
    String[] description = {"Go to the home page where you can view inspirational quotes and track your mood!", "Write about what's on your mind in our password protected diary. If you don't know what to write about, you can always answer our daily prompt!", "Track your sleep for today. View trends from the last week and view advice on how to improve your sleep.", "Need to talk to someone? Visit the resources page to find out more information.", "Fill out information about yourself! This will help make Sleep Easy more personalized."};

    int[] images = {R.drawable.ic_baseline_home_24, R.drawable.ic_baseline_book_24, R.drawable.ic_baseline_bar_chart_24, R.drawable.ic_baseline_phone_24,R.drawable.ic_baseline_person_24};

    String[] urls = {"home", "diary", "track", "resources", "survey"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_layout);
        lvProgram = findViewById(R.id.lvProgram);

        ProgramAdapter programAdapter = new ProgramAdapter(this, name, images, description, urls);
        lvProgram.setAdapter(programAdapter);
    }
}
