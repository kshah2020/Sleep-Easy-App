package com.example.app;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class Screen3 extends AppCompatActivity {

    ListView lvProgram;
    String[] name = {"National Suicide Prevention Hotline (24/7)", "Teen Mental Health Line (24/7)", "Grassroots Crisis Intervention (24/7)","Crisis Next Line (24/7)", "FIND A THERAPIST", "LEARN MORE", "Return to Menu"};
    String[] description = {"Call: 800-273-8255", "Call: 310-855-4673", "Call: 410-531-6006","Text SUPPORT to 741-741", "Find a therapist near you!","Learn more about topics like insomnia!", "Click here to go back to our screen selection menu!" };

    int[] images = {R.drawable.ic_baseline_phone_24, R.drawable.ic_baseline_phone_24, R.drawable.ic_baseline_phone_24, R.drawable.ic_baseline_phone_iphone_24, R.drawable.ic_baseline_computer_24, R.drawable.ic_baseline_computer_24, R.drawable.ic_baseline_keyboard_return_24};

    String[] urls = {"none", "none", "none", "none", "https://www.psychologytoday.com/us/therapists", "https://www.healthline.com/health/anxiety-insomnia", "screen select"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_3);
        lvProgram = findViewById(R.id.lvProgram);
        ProgramAdapter programAdapter = new ProgramAdapter(this, name, images, description, urls);
        lvProgram.setAdapter(programAdapter);
    }
}
