package com.example.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;


import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TextView;
import android.widget.Toast;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;


import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class Screen4 extends AppCompatActivity {

    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    Cursor cursor;
    Button menu;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_4);

        Toast.makeText(getApplicationContext(), "Remember to Log Today's Sleep", Toast.LENGTH_LONG).show();
        BarChart barChart = (BarChart) findViewById(R.id.barchart);
        TextView advice = (TextView)findViewById(R.id.textView4);
        menu = (Button)findViewById(R.id.tableofContents);

        DatabaseHelper dbH = new DatabaseHelper(Screen4.this);
        List<String> awake = dbH.getAwakeData();
        List<String> sleep = dbH.getSleepData();
        List<String> ratings = dbH.getRatings();


        ArrayList<Integer> amountSleep = new ArrayList<Integer>();
        amountSleep.add(1);
        amountSleep.add(2);
        amountSleep.add(3);
        amountSleep.add(4);
        amountSleep.add(5);
        amountSleep.add(6);


        List<String> sleep2 = sleep.subList(sleep.size()-6, sleep.size());
        List<String> awake2 = awake.subList(awake.size()-6, awake.size());

        for(int i = 0; i < 6; i++){
            String tempA = awake2.get(i);
            String tempS = sleep2.get(i);

            int hourA = Integer.valueOf(tempA.substring(0,2));
            int hourS = Integer.valueOf(tempS.substring(0,2));
            int elapsed = 0;

            boolean awakeAM = false;
            boolean sleepAM = false;
            if(tempA.substring(6).equals("AM")){
                awakeAM = true;
            }
            if(tempS.substring(6).equals("AM")){
                sleepAM = true;
            }

            if(awakeAM && sleepAM){
                if(hourS==12){
                    elapsed = hourA;
                }
                else { elapsed = hourA-hourS;}
            }
            else if(awakeAM && !sleepAM){
                int difference = 12-hourS;
                elapsed = Math.abs(hourA-12) + difference;
            }
            amountSleep.add(elapsed);
            //advice.setText(Integer.toString(hourA));
        }

        List<Integer> amount2 = amountSleep.subList(amountSleep.size()-6, amountSleep.size());

        ArrayList<BarEntry> entries = new ArrayList<>();
        entries.add(new BarEntry(amount2.get(0), 0));
        entries.add(new BarEntry(amount2.get(1), 1));
        entries.add(new BarEntry(amount2.get(2), 2));
        entries.add(new BarEntry(amount2.get(3), 3));
        entries.add(new BarEntry(amount2.get(4), 4));
        entries.add(new BarEntry(amount2.get(5), 5));

        BarDataSet bardataset = new BarDataSet(entries, "Cells");


        Instant now = Instant.now();
        ArrayList<String> labels = new ArrayList<String>();
        labels.add(now.minus(5, ChronoUnit.DAYS).toString().substring(5,10));
        labels.add(now.minus(4, ChronoUnit.DAYS).toString().substring(5,10));
        labels.add(now.minus(3, ChronoUnit.DAYS).toString().substring(5,10));
        labels.add(now.minus(2, ChronoUnit.DAYS).toString().substring(5,10));
        labels.add(now.minus(1, ChronoUnit.DAYS).toString().substring(5,10));
        labels.add(java.time.LocalDate.now().toString().substring(5,10));


        BarData data = new BarData(labels, bardataset);
        barChart.setData(data); // set the data and list of labels into chart
        barChart.setDescription("Time Slept");  // set the description
        bardataset.setColors(ColorTemplate.COLORFUL_COLORS);
        barChart.animateY(5000);

        int sum = 0;
        for(int i = 0; i < 6; i++){
            sum+=amount2.get(0);
        }

        double avgSleep = (double)sum/6;


        //generate advice
        //{"Terrible", "Okay", "Mediocre", "Great", "Perfect"};
        String recentRating = ratings.get((ratings.size()-1));
        String adviceText = "";
        String adviceText2 = "";

        adviceText += "On average, you got " + avgSleep + " hours of sleep\n\n";

        if(amountSleep.get(amountSleep.size()-1) < 8) {
            adviceText += "Oh no! You didn't get enough sleep (you need 8-10). Try to reduce your naps or build a schedule!\n";
        }
        else if(amountSleep.get(amountSleep.size()-1) >= 8 || amountSleep.get(amountSleep.size()) <= 10) {
            adviceText += "Good job! Keep sleeping between 8-10 hours to have a great, productive day!\n";
        }
        else if(amountSleep.get(amountSleep.size()-1) > 10) {
            adviceText += "Good job! Keep sleeping for 8 hours or more to have a great, productive day! But remember, try to sleep between 8-10 hours to prevent fatigue!\n";
        }

        if(recentRating.equals("Terrible")){
            adviceText += "\nLooks like you didn't sleep too well! To sleep better try to \"Tranquility\" or \"Deep Sleep\" playlist on spotify!";
        }
        else if(recentRating.equals("Okay")){
            adviceText += "\nLooks like you didn't sleep too well! To sleep better try to \"Tranquility\" or \"Deep Sleep\" playlist on spotify!";
        }
        else if(recentRating.equals("Mediocre")){
            adviceText += "\nYour sleep was satisfactory! To improve this to a better level try the \"Musical Therapy\" playlist on spotify!";
        }
        else if(recentRating.equals("Great")){
            adviceText += "\nGood job on your quality sleep! Keep it up! Make sure to check out spotify's sleep playlists if you need help";
        }
        else if(recentRating.equals("Perfect")){
            adviceText += "\nGood job on your quality sleep! Keep it up! Make sure to check out spotify's sleep playlists if you need help";
        }

        advice.setText(adviceText);

        Button quizLaunch = (Button)findViewById(R.id.sleepQuiz);
        quizLaunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SleepQuiz.class);
                startActivity(intent);
            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Menu.class);
                startActivity(intent);
            }
        });


        //launch on another app (outside)
        Button googleB = (Button)findViewById(R.id.meditation);
        googleB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.youtube.com/watch?v=aEqlQvczMJQ";
                Uri website = Uri.parse(url);

                Intent goToWebsite = new Intent(Intent.ACTION_VIEW,website);
                if(goToWebsite.resolveActivity(getPackageManager()) != null){
                    startActivity(goToWebsite);
                }
            }
        });

        Button spotifyB = (Button)findViewById(R.id.spotify);
        spotifyB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://open.spotify.com/playlist/7Bd8TnSdpX0GtDHf3puVW1";
                Uri website = Uri.parse(url);

                Intent goToWebsite = new Intent(Intent.ACTION_VIEW,website);
                if(goToWebsite.resolveActivity(getPackageManager()) != null){
                    startActivity(goToWebsite);
                }
            }
        });
    }



}

