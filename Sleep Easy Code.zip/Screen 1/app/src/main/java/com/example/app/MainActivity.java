package com.example.app;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Random;
import java.util.UUID;

import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity implements TimePickerDialog.OnTimeSetListener, SeekBar.OnSeekBarChangeListener {

    SeekBar seekBar;
    TextView textView;
    TextView dateText;
    Button buttonQuote, doctorNote;
    private ImageView ProfileImage;
    ImageView menu;
    private DatePickerDialog datePickerDialog;
    private Button dateButton;
    Random random = new Random();
    public Uri imageUri;
    private FirebaseStorage storage;
    private StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekBar = (SeekBar) findViewById(R.id.seekBarID);
        textView = (TextView) findViewById(R.id.textViewID);

        buttonQuote = findViewById(R.id.buttonNextQuote);
        Button button = (Button) findViewById(R.id.button);
        initDatePicker();

        dateButton = findViewById(R.id.datePickerbutton);
        dateButton.setText(getTodaysDate());
        //dateText = findViewById(R.id.date);
        menu = findViewById(R.id.navigate);

        doctorNote = findViewById(R.id.doctorNote);
        ProfileImage = findViewById(R.id.profile_image);
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        //Toolbar toolbar1 = (Toolbar)findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar1);


        ProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                choosePicture();
            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, com.example.app.Menu.class);
                startActivity(intent);
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress == 0) {
                    textView.setText("Mad");
                } else if (progress == 1) {
                    textView.setText("Sad");
                } else if (progress == 2) {
                    textView.setText("Tired");
                } else if (progress == 3) {
                    textView.setText("Neutral");
                } else if (progress == 4) {
                    textView.setText("Happy");
                } else if (progress == 5) {
                    textView.setText("Energetic");
                } else if (progress == 6) {
                    textView.setText("Excited");
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment timePicker = new TimePickerFragment();
                timePicker.show(getSupportFragmentManager(), "Time Picker");
            }
        });

        buttonQuote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayQuote();
            }
        });

        doctorNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayNote();
            }
        });
    }

    private void choosePicture() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, 1);

    }

    private void displayNote() {
        int randNum = random.nextInt((20+1) - 1) + 1;
        String randNote = "";
        switch (randNum) {
            case 1:
                randNote = getString(R.string.note1);
                break;
            case 2:
                randNote = getString(R.string.note2);
                break;
            case 3:
                randNote = getString(R.string.note3);
                break;
            case 4:
                randNote = getString(R.string.note4);
                break;
            case 5 :
                randNote = getString(R.string.note5);
                break;
            case 6:
                randNote = getString(R.string.note6);
                break;
            case 7:
                randNote = getString(R.string.note7);
                break;
            case 8:
                randNote = getString(R.string.note8);
                break;
            case 9:
                randNote = getString(R.string.note9);
                break;
            case 10:
                randNote = getString(R.string.note10);
                break;
            case 11:
                randNote = getString(R.string.note11);
                break;
            case 12:
                randNote = getString(R.string.note12);
                break;
            case 13:
                randNote = getString(R.string.note13);
                break;
            case 14:
                randNote = getString(R.string.note14);
                break;
            case 15:
                randNote = getString(R.string.note15);
                break;
            case 16:
                randNote = getString(R.string.note16);
                break;
            case 17:
                randNote = getString(R.string.note17);
                break;
            case 18:
                randNote = getString(R.string.note18);
                break;
            case 19:
                randNote = getString(R.string.note19);
                break;
            case 20:
                randNote = getString(R.string.note20);
                break;
        }
        doctorNote.setText(randNote);
    }

    private String getTodaysDate() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        month = month + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return makeDateString(day, month, year);
    }

    private void initDatePicker() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                month = month + 1;
                String date = makeDateString (dayOfMonth, month, year);
                dateButton.setText(date);
                //dateText.setText(date);
            }
        };
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        int style = AlertDialog.THEME_HOLO_LIGHT;

        datePickerDialog = new DatePickerDialog(this, style, dateSetListener, year, month, day);
    }

    private String makeDateString(int dayOfMonth, int month, int year) {
        return getmonthFormat(month) + " " + dayOfMonth + " " + year;
    }

    private String getmonthFormat(int month) {
        if(month == 1)
            return "JAN";
        if(month == 2)
            return "FEB";
        if(month == 3)
            return "MAR";
        if(month == 4)
            return "APR";
        if(month == 5)
            return "MAY";
        if(month == 6)
            return "JUN";
        if(month == 7)
            return "JUL";
        if(month == 8)
            return "AUG";
        if(month == 9)
            return "SEP";
        if(month == 10)
            return "OCT";
        if(month == 11)
            return "NOV";
        if(month == 12)
            return "DEC";
        return "JAN";
    }

    public void openDatePicker(View view) {
        datePickerDialog.show();
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

        TextView textView = (TextView) findViewById(R.id.textView);
        textView.setText(hourOfDay + ":" + minute);
    }

    //profile image
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data!=null && data.getData()!=null) {
            imageUri = data.getData();
            ProfileImage.setImageURI(imageUri);
            uploadPicture();
            }

        }

    private void uploadPicture() {

        final ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle("Uploading Image...");
        pd.show();

        final String randomKey = UUID.randomUUID().toString();
        // Create a reference to "mountains.jpg"
        StorageReference mountainsRef = storageReference.child("images/" + randomKey);

        mountainsRef.putFile(imageUri)
        // Create a reference to 'images/mountains.jpg'
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        pd.dismiss();
                        Snackbar.make(findViewById(android.R.id.content), "Image Uploaded.", Snackbar.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pd.dismiss();
                        Toast.makeText(getApplicationContext(), "Failed to Upload.", Toast.LENGTH_LONG).show();
                    }
                })
        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                double progressPercent = (100.00 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                pd.setMessage("Progress: " + (int) progressPercent + "%");
            }
        });
     }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

    }

    @Override
    public void onStartTrackingTouch (SeekBar seekBar){
    }

    @Override
    public void onStopTrackingTouch (SeekBar seekBar){
    }

    public void displayQuote() {
        int randNum = random.nextInt((20+1) - 1) + 1;
        String randQuote = "";
        switch (randNum) {
            case 1:
                randQuote = getString(R.string.quote1);
                break;
            case 2:
                randQuote = getString(R.string.quote2);
                break;
            case 3:
                randQuote = getString(R.string.quote3);
                break;
            case 4:
                randQuote = getString(R.string.quote4);
                break;
            case 5 :
                randQuote = getString(R.string.quote5);
                break;
            case 6:
                randQuote = getString(R.string.quote6);
                break;
            case 7:
                randQuote = getString(R.string.quote7);
                break;
            case 8:
                randQuote = getString(R.string.quote8);
                break;
            case 9:
                randQuote = getString(R.string.quote9);
                break;
            case 10:
                randQuote = getString(R.string.quote10);
                break;
            case 11:
                randQuote = getString(R.string.quote11);
                break;
            case 12:
                randQuote = getString(R.string.quote12);
                break;
            case 13:
                randQuote = getString(R.string.quote13);
                break;
            case 14:
                randQuote = getString(R.string.quote14);
                break;
            case 15:
                randQuote = getString(R.string.quote15);
                break;
            case 16:
                randQuote = getString(R.string.quote16);
                break;
            case 17:
                randQuote = getString(R.string.quote17);
                break;
            case 18:
                randQuote = getString(R.string.quote18);
                break;
            case 19:
                randQuote = getString(R.string.quote19);
                break;
            case 20:
                randQuote = getString(R.string.quote20);
                break;
        }
        buttonQuote.setText(randQuote);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    /*@Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id==R.id.share){
            Toast.makeText(getApplicationContext(),"You Clicked Share",Toast.LENGTH_SHORT).show();
        }else if(id==R.id.about){
            Toast.makeText(getApplicationContext(),"You Clicked About",Toast.LENGTH_SHORT).show();
        } else if(id==R.id.exit){
            Toast.makeText(getApplicationContext(),"You Clicked Exit",Toast.LENGTH_SHORT).show();
        }
        return true;
    }*/
}