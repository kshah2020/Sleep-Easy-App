package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;

import com.hanks.passcodeview.PasscodeView;

public class Screen2_Main extends AppCompatActivity {
    public Button dailyPrompt;
    public Button help;
    public Button diary;
    public ImageView menu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen2_main);

        dailyPrompt = (Button)findViewById(R.id.dailyPrompt);
        dailyPrompt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( getApplicationContext(), PromptMain.class);
                startActivity(intent);
            }
        });


        help = (Button)findViewById(R.id.Help);
        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( getApplicationContext(), Help.class);
                startActivity(intent);
            }
        });

        diary = (Button)findViewById(R.id.Diary);
        diary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( getApplicationContext(), Password.class);
                startActivity(intent);
            }
        });

        menu = findViewById(R.id.navigate);
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), com.example.app.Menu.class);
                startActivity(intent);
            }
        });

    }
}