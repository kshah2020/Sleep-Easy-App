package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.ArrayList;
import java.lang.Math;
import java.util.Date;

public class PromptMain extends AppCompatActivity {

    public Button btnSubmit, return1, btnView;
    private EditText txtResponse;
    DiaryDBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prompt_main);

        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance().format(calendar.getTime());

        TextView textViewDate = findViewById(R.id.text_view_date);
        textViewDate.setText(currentDate);

        //TextView responseRecorded = findViewById(R.id.txt_recorded);
        //responseRecorded.setVisibility(View.GONE);

        DB = new DiaryDBHelper(this);
        ArrayList<String[]> week = new ArrayList<>();

        String[] mon = {"What’s the weather outside your window doing right now? If that’s not inspiring, what’s the weather like somewhere you wish you could be?", " What’s for breakfast? Dinner? Lunch? Or maybe you could write a poem about that time you met a friend at a cafe.", "Write something inspired by a recent dream you had."};
        String[] tues = {"Choose an animal. Write about it!", "Create a poem, short story, or journal entry about a conversation you’ve overheard.", " Open up a dictionary to a random word. Define what that word means to you."};
        String[] wed = {"Take any poem or short story you enjoy. Rewrite it in your own words.", "Sit outside for about an hour. Write down the sounds you hear.", "Write about a recent conflict that you dealt with in your life."};
        String[] thurs = {"Write about a secret you’ve kept from someone else.", "Take a popular song off the radio and rewrite it as a poem in your own words.", "Go to Wikipedia and click on the Random Article. Write about whatever the page you get."};
        String[] fri = {"Write about a recipe for something abstract, such as a feeling.", " Write a quick little poem or story about the last person you spoke with.", " Make a list of the first 5 adjectives that pop into your head. Use these 5 words in your story, poem, or journal entry."};
        String[] sat = {"Think of something you’ve recently discovered and use it as inspiration.", "Write about your complaints about something.", "Set a timer for 5 minutes and just write. Don’t worry about it making sense or being perfect."};
        String[] sun = {"Write a motivational poem or journal entry about positive traits that make you who you are.", "Write a poem or journal entry that is all about things you are thankful for.", "Write about an epic battle, whether real, fictional or figurative."};

        week.add(sun);
        week.add(mon);
        week.add(tues);
        week.add(wed);
        week.add(thurs);
        week.add(fri);
        week.add(sat);

        Date d = new Date();
        int dayOfWeek = d.getDay();
        TextView textPrompt = findViewById(R.id.text_prompt);
        int random = (int)(Math.random()*3);
        String prompt = week.get(dayOfWeek)[random];
        textPrompt.setText(prompt);

        txtResponse = findViewById(R.id.txtResponse);
        btnSubmit = findViewById(R.id.btn_save);
        txtResponse.addTextChangedListener(btnSub);


        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String journal = currentDate + "\n" + prompt + "\n" + txtResponse.getText().toString();
                Boolean checkinsertdata = DB.insertData(journal);
                if (checkinsertdata == true)
                {
                    Toast.makeText(getApplicationContext(), "New Entry Submitted", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), "New Entry Not Submitted", Toast.LENGTH_SHORT).show();
                }
            }
        });


        return1 = (Button)findViewById(R.id.return_1);
        return1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Screen2_Main.class);
                startActivity(intent);
            }
        });

        btnView = (Button)findViewById(R.id.btnView);
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = DB.getData();

                if (res.getCount() == 0)
                {
                    Toast.makeText(getApplicationContext(), "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext())
                {
                    buffer.append("Date: " +res.getString(0) +"\n\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(getApplicationContext());
                builder.setCancelable(true);
                builder.setTitle("User Entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
    }

    private final TextWatcher btnSub = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String input = txtResponse.getText().toString().trim();
            btnSubmit.setEnabled(!input.isEmpty());
        }
        @Override
        public void afterTextChanged(Editable s) {
        }
    };
}