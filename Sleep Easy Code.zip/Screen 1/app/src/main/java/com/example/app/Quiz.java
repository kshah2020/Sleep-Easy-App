package com.example.app;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Quiz extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        if(getIntent().hasExtra("something")){
            TextView tv = (TextView) findViewById(R.id.exampleText);
            String text = getIntent().getExtras().getString("something");
            tv.setText(text);
        }
    }



}
