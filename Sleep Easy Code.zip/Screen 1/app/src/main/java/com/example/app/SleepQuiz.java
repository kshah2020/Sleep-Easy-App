package com.example.app;

import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SleepQuiz extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String[] users = {"Terrible", "Okay", "Mediocre", "Great", "Perfect"};
    String[] timeAwake = new String[1];
    String[] timeSleep = new String[1];
    String[] num = new String[1];
    TextView timer1, timer2;
    int t1H, t1M, t2H, t2M;
    Button submit;
    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sleep_quiz);


        Spinner spin = (Spinner)findViewById(R.id.picker);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, users);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(adapter);
        spin.setOnItemSelectedListener(this);

        timer1 = (TextView)findViewById(R.id.timer1);
        timer2 = (TextView)findViewById(R.id.timer2);

        timer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(
                        com.example.app.SleepQuiz.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        new TimePickerDialog.OnTimeSetListener(){
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute){
                                t1H = hourOfDay;
                                t1M = minute;
                                //store hour and minute in string
                                String time = t1H + ":" + t1M;
                                timeAwake[0] = time;
                                SimpleDateFormat f24Hours = new SimpleDateFormat(
                                        "HH:mm"
                                );
                                try {
                                    Date date = f24Hours.parse(time);
                                    //12 hours time format
                                    SimpleDateFormat f12Hours = new SimpleDateFormat(
                                            "hh:mm aa"
                                    );
                                    //set selected time on text view
                                    timeAwake[0] = f12Hours.format(date);
                                    timer1.setText((f12Hours.format(date)));
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, 12, 0, false
                );
                //set transparent background
                timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                //display previous selected time
                timePickerDialog.updateTime(t1H, t1M);
                //show
                timePickerDialog.show();
            }
        });

        timer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(
                        com.example.app.SleepQuiz.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        new TimePickerDialog.OnTimeSetListener(){
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute){
                                t2H = hourOfDay;
                                t2M = minute;
                                //store hour and minute in string
                                String time = t2H + ":" + t2M;
                                SimpleDateFormat f24Hours = new SimpleDateFormat(
                                        "HH:mm"
                                );
                                try {
                                    Date date = f24Hours.parse(time);
                                    //12 hours time format
                                    SimpleDateFormat f12Hours = new SimpleDateFormat(
                                            "hh:mm aa"
                                    );
                                    //set selected time on text view
                                    timeSleep[0] = f12Hours.format(date);
                                    timer2.setText((f12Hours.format(date)));
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, 12, 0, false
                );
                //set transparent background
                timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                //display previous selected time
                timePickerDialog.updateTime(t2H, t2M);
                //show
                timePickerDialog.show();

            }
        });

        submit = (Button)findViewById(R.id.submit);
        openHelper = new com.example.app.DatabaseHelper(this);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ContentValues contentV = new ContentValues();
                //contentV.put(DatabaseHelper.COL_ANS_2, "8+ hours");
                //long i = db.insert(DatabaseHelper.TABLE_ANS, null, contentV);

                String awake = timeAwake[0];
                String sleep = timeSleep[0];

                db=openHelper.getWritableDatabase();
                db=openHelper.getReadableDatabase();
                insertSleepData(sleep);

                db=openHelper.getWritableDatabase();
                db=openHelper.getReadableDatabase();
                insertAwakeData(awake);

                db=openHelper.getWritableDatabase();
                db=openHelper.getReadableDatabase();
                insertRating(num[0]);

                //String qry = "SELECT " + DatabaseHelper.COL_AWAKE_2 +" FROM " + DatabaseHelper.TABLE_AWAKE;
                //cursor=db.rawQuery(qry, null);
                /*if(cursor!=null){
                    if(cursor.getCount()>0){
                        cursor.moveToNext();
                    }
                }else {
                    ContentValues contentVa = new ContentValues();
                    contentVa.put(DatabaseHelper.COL_AWAKE_2, "8 hours");
                    long ii = db.insert(DatabaseHelper.TABLE_AWAKE, null, contentVa);
                }*/



                //insertAwakeData(awake);
                //insertSleepData(sleep);
                /*cursor = db.rawQuery("SELECT " + DatabaseHelper.TABLE_AWAKE +"."+DatabaseHelper.COL_AWAKE_2+", "+ DatabaseHelper.TABLE_ASLEEP+"."+DatabaseHelper.COL_ASLEEP_2 + " FROM " + DatabaseHelper.TABLE_AWAKE+" INNER JOIN (SELECT " + DatabaseHelper.COL_ASLEEP_2+ " FROM " + DatabaseHelper.TABLE_ASLEEP + " ORDER BY ID DESC LIMIT 1) " + DatabaseHelper.TABLE_ASLEEP + " ON " + DatabaseHelper.TABLE_ASLEEP + "."+DatabaseHelper.COL_ASLEEP_2 +"=" + DatabaseHelper.TABLE_AWAKE + "."+DatabaseHelper.COL_AWAKE_2+"", null);

                if(cursor != null){
                    if(cursor.getCount()>0){
                        cursor.moveToNext();
                        ContentValues contentValues = new ContentValues();
                        contentValues.put(DatabaseHelper.COL_ASLEEP_2, "ENOUGH");
                        long dd = db.insert(DatabaseHelper.TABLE_ASLEEP, null, contentValues);
                    } else {
                        ContentValues contentValues = new ContentValues();
                        contentValues.put(DatabaseHelper.COL_ASLEEP_2, "NOT ENOUGH");
                        long dd = db.insert(DatabaseHelper.TABLE_ASLEEP, null, contentValues);
                    }
                }*/
                //Toast.makeText(getApplicationContext(), "the answer is submitted successfully. the submitted answer is " + radioButton.getText(), Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(), Screen4.class);
                startActivity(intent);
            }
        });
    }

    public void insertAwakeData(String value){
        ContentValues content = new ContentValues();
        content.put(com.example.app.DatabaseHelper.COL_WAKE_2, value);
        long id = db.insert(com.example.app.DatabaseHelper.TABLE_WAKE, null, content);
    }


    public void insertSleepData(String value){
        ContentValues content = new ContentValues();
        content.put(com.example.app.DatabaseHelper.COL_SLEEP_2, value);
        long id = db.insert(com.example.app.DatabaseHelper.TABLE_SLEEP, null, content);
    }

    public void insertRating(String value){
        ContentValues content = new ContentValues();
        content.put(com.example.app.DatabaseHelper.COL_RATING_2, value);
        long id = db.insert(com.example.app.DatabaseHelper.TABLE_RATING, null, content);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(getApplicationContext(), "Rate Your Sleep: "+users[position] ,Toast.LENGTH_SHORT).show();
        num[0] = users[position];
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}