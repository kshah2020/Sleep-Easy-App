package com.example.app;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ProgramAdapter extends ArrayAdapter<String> {

    Context context;
    int[] images;
    String[] names;
    String[] descriptions;
    String[] urls;

    public ProgramAdapter(Context context, String[] names, int[] images, String[] descriptions, String[] urls) {
        super(context, R.layout.single_item,R.id.TV1, names);
        this.context = context;
        this.images = images;
        this.descriptions =descriptions;
        this.names = names;
        this.urls = urls;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View singleItem = convertView;
        ProgramViewHolder holder = null;
        if(singleItem==null){
            LayoutInflater layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            singleItem = layoutInflater.inflate(R.layout.single_item, parent, false);
            holder = new ProgramViewHolder(singleItem);
            singleItem.setTag(holder);
        }else{
            holder = (ProgramViewHolder) singleItem.getTag();
        }

        holder.itemImage.setImageResource(images[position]);
        holder.programTitle.setText(names[position]);
        holder.programDescription.setText(descriptions[position]);
        singleItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (urls[position].equals("none")) {
                    Toast.makeText(getContext(), descriptions[position], Toast.LENGTH_LONG).show();
                }else if (urls[position].equals("home")) {
                    Intent intent = new Intent(context.getApplicationContext(), MainActivity.class);
                    context.startActivity(intent);
                }else if (urls[position].equals("diary")) {
                    Intent intent = new Intent(context.getApplicationContext(), Screen2_Main.class);
                    context.startActivity(intent);
                }
                else if (urls[position].equals("track")) {
                    Intent intent = new Intent(context.getApplicationContext(), Screen4.class);
                    context.startActivity(intent);
                }else if (urls[position].equals("resources")) {
                    Intent intent = new Intent(context.getApplicationContext(), Screen3.class);
                    context.startActivity(intent);
                }else if (urls[position].equals("survey")) {
                   Intent intent = new Intent(context.getApplicationContext(), Screen5.class);
                    context.startActivity(intent);
                }else if (urls[position].equals("screen select")) {
                    Intent intent = new Intent(context.getApplicationContext(), Menu.class);
                    context.startActivity(intent);
                }
                else {
                    Intent openLink = new Intent(Intent.ACTION_VIEW, Uri.parse(urls[position]));
                    context.startActivity(openLink);
                }
            }
        });

        return singleItem;
    }
}
